# ETLPackages

SHOS Business Intelligence/Reporting Group ETL Packages

Github Repository https://github.com/SHOSBIGROUP/ETLPackages/

DO NOT COMMIT CONFIG FILES OF ANY TYPE!
