Use sho_staging;

truncate table sho_staging.netsuite.location;

truncate table sho_staging.netsuite.region;

truncate table sho_staging.netsuite.district;